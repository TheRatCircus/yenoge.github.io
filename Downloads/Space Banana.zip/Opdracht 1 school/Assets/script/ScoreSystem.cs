using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreSystem : MonoBehaviour
{
    public int ScoreLeft;
    public int ScoreRight;

    public Text ScoreLeftText;
    public Text ScoreRightText;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        ScoreLeftText.text = ScoreLeft.ToString();
        ScoreRightText.text = ScoreRight.ToString();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        name = collision.gameObject.name;

        if (name == "Right Wall")
        {
            ScoreLeft++;
        }

        if (name == "Left Wall")
        {
            ScoreRight++;
        }
    }

}