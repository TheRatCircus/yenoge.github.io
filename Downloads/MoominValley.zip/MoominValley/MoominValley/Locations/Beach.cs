﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley.Locations
{
    internal class Beach
    {
        public string discription = "The beach is a very breezy open area on the edge of moominvalley, you see a dock with a broken boat and stones surrounding you";
        public string paths = "dirt and sand paths";
        
    }
}
