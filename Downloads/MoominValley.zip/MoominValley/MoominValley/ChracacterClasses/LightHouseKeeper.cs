﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley.ChracacterClasses
{
    internal class LightHouseKeeper
    {
        public string name = "Light house keeper";
        public string species = "Human";
        public int age = 37;

        public LightHouseKeeper(string nm, string sp, int age)
        {
            this.name = nm;
            this.species = sp;
            this.age = age;
        }

    }
}
