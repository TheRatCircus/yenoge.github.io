﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley.ChracacterClasses
{
    internal class LittleMy
    {
        public string name = "Little My";
        public string species = "Human";
        public int age = 13;

        public LittleMy(string nm, string sp, int age)
        {
            this.name = nm;
            this.species = sp;
            this.age = age;
        }

    }
}
