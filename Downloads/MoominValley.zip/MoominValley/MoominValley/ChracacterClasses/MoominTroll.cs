﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley.ChracacterClasses
{
    internal class MoominTroll
    {
        public string name = "Moomin Troll";
        public string species = "Moomin";
        public int age = 19;

        public MoominTroll(string nm, string sp, int age)
        {
            this.name = nm;
            this.species = sp;
            this.age = age;
        }
    }
}
