﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley.ChracacterClasses
{
    internal class MoominPapa
    {
        public string name = "Moomin Papa";
        public string species = "Moomin";
        public int age = 39;

         public MoominPapa(string nm, string sp, int age)
        {
            this.name = nm;
            this.species = sp;
            this.age = age;
        }
    }
}
