﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley
{
    internal class Player
    {
        public string name;
        public string species;

      

        public Player()
        {
          
        }
        
        public void SetName(string nm)
        {
            this.name = nm;
        }

        public string GetName(string nm)
        {
            return this.name;
        }

        public void SetSpecies(string sp)
        {
            this.name = sp;
        }

        

    }
}
