using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Players : MonoBehaviour
{

    public float speed = 10f;
    public float maxY;
    public float minY;


    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 pos = transform.position;

        if (Input.GetKey("w") && maxY > transform.position.y)
        {
            pos.y += speed * Time.deltaTime;
        }

        if (Input.GetKey("s") && minY < transform.position.y)
        {
            pos.y -= speed * Time.deltaTime; 
        }

        transform.position = pos;
    }
}
