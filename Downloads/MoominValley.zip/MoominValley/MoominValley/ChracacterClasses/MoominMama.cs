﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoominValley.ChracacterClasses
{
    internal class MoominMama
    {
        public string name = "Moomin Mamma";
        public string species = "Moomin";
        public int age = 37;

        public MoominMama(string nm, string sp, int age)
        {
            this.name = nm;
            this.species = sp;
            this.age = age;
        }
    }
}
