﻿using System.ComponentModel.Design;
using System.Transactions;

namespace MoominValley
{
    class Program
    {
        public static Player currentPlayer = new Player();

        static void Main(string[] args)
        {
            Start();
            
            string help = Console.ReadLine();
            if (help == "help")
            {
                Console.WriteLine("Use 1 or 2 for optional paths throught the story");
            }

        }

        

        static void Start()
        {
            Console.WriteLine("Welcome to MoominValley!");
            Console.WriteLine("Name your character");
            currentPlayer.SetName(Console.ReadLine());
            Console.WriteLine("What sort of species are you?");
            currentPlayer.SetSpecies(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("You awake at a pier in MoominValley. You have no idea how you got here.");
            if (currentPlayer.name == "")
                Console.WriteLine("You can't even remember your own name...");
            else
                Console.WriteLine("all you remember is that your name is " + currentPlayer.name);
            Console.WriteLine("Press enter to Contineu");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("you stand up and walk around, looking around your surroundings until you see a small little child walk towards you.");
            Console.WriteLine("The small child has a weirdly shaped onion head and red hair.");
            Console.WriteLine("'What are you looking at?' said the little girl.");
            Console.WriteLine("You look at her and say 'I'm looking at you.'");
            Console.WriteLine("'oh so you're a smart one huh?' she said as she looked mad at you. 'Who are you anyways?'");
            if (currentPlayer.name == "")
                Console.WriteLine("'Well i dont really know my name..' you say as you look down.");
            else
                Console.WriteLine("You look at her and say 'I'm " + currentPlayer.name + " atleast i think thats my name.'");
            if (currentPlayer.species == "")
                Console.WriteLine("'Well i'm Little My, and i don't remember ever seeing something like you before.'");
            else
                Console.WriteLine("'Well i'm Little My, and i don't remember ever seeing a " + currentPlayer.species + " like you before.'");
            Console.WriteLine("'Well i'm not from around here, i just woke up here and i don't remember anything.'");
            Console.WriteLine("'Well that sound like a you problem!' said little My as she walked off into the forrest, leaving you alone");
            Console.WriteLine("Press enter to Contineu");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("After a while you decide that waiting won't get you anywhere, you decide to go search for help.");
            Console.WriteLine("Before you are two paths, one sandy path heading further on the beach and a grassy path leading to the forrest, which path do you choose?");
            Console.WriteLine("1. Sandy path");
            Console.WriteLine("2. Grass path");
            string path = Console.ReadLine();


            if (path == "1")
            {
                Console.Clear();
                Console.WriteLine("You walk down the sandy path and after a while you see a small hut on the beach.");
                Console.WriteLine("You hear some man screaming as you hear a concertina being played, do you check it out or do you contineu on?");

                Console.WriteLine("1. You check out the hut.");
                Console.WriteLine("2. You contineu on further the path.");
                string music = Console.ReadLine();
                
                if (music == "1")
                {
                    Console.Clear();
                    Console.WriteLine("You decide to check out the hut, you walk up to the hut and knock on the door.");
                    Console.WriteLine("'Come in!' the man shouted as he kept yelping and playing the concertina.");
                    Console.WriteLine("As you walk in you see a man with a long beard dancing on a chair as he gets some sort of shock from weird white tube creatures with hands.");
                    Console.WriteLine("'Are you ok?' you ask the man as you look slightly worried, thinking the man is in pain.");
                    Console.WriteLine("'I'm totally fine! he says as he keeps dancing and playing the concertina. 'I'm just having a good time with the Hattifatteners!'");
                    Console.WriteLine("'Would you like a discription about the Hattifatteners?'");
                    Console.WriteLine("1. Yes");
                    Console.WriteLine("2. No, Contineu the game");
                    string hattifatteners = Console.ReadLine();

                    bool contineu = false;
                    if (hattifatteners == "1")
                    {
                        Console.Clear();
                        Console.WriteLine("Hattifatteners are mysterious creatures whose only motivation in life is to keep moving towards the horizon. They are pale grey-white in colour and look something like mushroom stalks with paws that extend directly from their trunks. They grow from little white seeds – but only if the seeds are sown on Midsummer’s Eve – and can become charged up with electricity in lightning storms.");
                        Console.WriteLine();
                        contineu = true;
                    }
                    
                    if (hattifatteners == "2" || contineu == true)
                    {
                        contineu = false;
                        Console.Clear();
                        Console.WriteLine("'I'm the lighthouse keeper! nice to meet you sea urchin!' he shouts");
                        Console.WriteLine("'I like the music!' you shout back.");
                        Console.WriteLine("'I'm a bit busy as you can see! maybe see me another time!' he laughs as he keeps playing the concertina.");
                        Console.WriteLine("You go out of the hut as you head on back to the beginning of the path where you get to choose between the sandpath and grass path");
                        Console.WriteLine("1. Sandy path");
                        Console.WriteLine("2. Grass path");
                        string path2 = Console.ReadLine();
                        
                        if (path2 == "1")
                        {
                            Console.Clear();
                            Console.WriteLine("test");
                        }

                        if (path2 == "2")
                        {
                            Console.Clear();
                        }
                    }
                }

                if (music == "2")
                {
                    Console.Clear();
                    Console.WriteLine("test");
                }

            }

            if (path == "2")
            {
                Console.Clear();
                Console.WriteLine("you walk on the path of grass, you look around as there are giant trees covering your surroundings, you hear birds chirping and animals sleeping");
                Console.WriteLine("As you contineu on you hear someone playing a hormonica");
            }
    }
    }
}
