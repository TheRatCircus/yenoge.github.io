# Changelog
## [1.0.0] - 2019-01-25
###Added
- This is the first release of Sprite Editor, as a Package
