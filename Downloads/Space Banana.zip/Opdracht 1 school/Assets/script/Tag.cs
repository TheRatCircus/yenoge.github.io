using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tag : MonoBehaviour
{
    // Start is called before the first frame update
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Block 2"));
        {
            Debug.Log("pingpong");
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
